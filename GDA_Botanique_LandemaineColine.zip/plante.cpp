#ifndef plante_CPP
#define plante_CPP
#include <string>
#include <iostream>

    void plante::engrais(){
    }

    void plante::arrosage(){
    }

    void plante::soin(){
    }

    void plante::taillage(){
    }
    
    void plante::affiche(){
    }

#endif